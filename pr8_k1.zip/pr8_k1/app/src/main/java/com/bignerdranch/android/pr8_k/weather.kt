package com.bignerdranch.android.pr8_k

import android.support.v7.app.AppCompatActivity
import android.os.Bundle

class weather : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_weather)
    }
}