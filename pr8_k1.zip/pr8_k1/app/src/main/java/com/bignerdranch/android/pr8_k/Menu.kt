package com.bignerdranch.android.pr8_k

import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.v4.app.Fragment
import android.view.MenuInflater

class Menu : Fragment() {
    //override fun onCreate(savedInstanceState: Bundle?) {
    //    super.onCreate(savedInstanceState)
    //    setContentView(R.layout.activity_menu)
    //}
    override fun onDetach() {
        super.onDetach()
        callbacks = null
    }
    fun onCreateOptionsMenu(menu: Menu, inflater: MenuInflater) {
        super.onCreateOptionsMenu(menu, inflater)
        inflater.inflate(R.menu.menu2, menu)
    }
}